﻿using System.Reflection;

[assembly: AssemblyTitle("Octokit.Reactive")]
[assembly: AssemblyDescription("An IObservable based GitHub API client library for .NET using Reactive Extensions")]
